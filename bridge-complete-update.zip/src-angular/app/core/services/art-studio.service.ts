/**
 * Bridge Art Studio Module - Angular Service
 */

import { Injectable } from '@angular/core'
import { BehaviorSubject } from 'rxjs'
import { 
  AlbumArtResult, 
  ArtDownloadProgress, 
  ArtDownloadOptions,
  BackgroundGenerateOptions,
  ChartArtMatch 
} from '../../../../src-shared/interfaces/art-studio.interface.js'

@Injectable({
  providedIn: 'root',
})
export class ArtStudioService {
  private downloadProgressSubject = new BehaviorSubject<ArtDownloadProgress | null>(null)
  private isProcessingSubject = new BehaviorSubject<boolean>(false)

  readonly downloadProgress$ = this.downloadProgressSubject.asObservable()
  readonly isProcessing$ = this.isProcessingSubject.asObservable()

  constructor() {
    this.setupIpcListeners()
  }

  private setupIpcListeners(): void {
    window.electron.on.artDownloadProgress((progress: ArtDownloadProgress) => {
      this.downloadProgressSubject.next(progress)
      
      if (progress.phase === 'complete' || progress.phase === 'error') {
        this.isProcessingSubject.next(false)
      } else {
        this.isProcessingSubject.next(true)
      }
    })
  }

  async searchAlbumArt(artist: string, album: string): Promise<AlbumArtResult[]> {
    try {
      return await window.electron.invoke.artSearchAlbumArt({ artist, album })
    } catch (err) {
      console.error('Album art search failed:', err)
      throw err
    }
  }

  async downloadImage(options: ArtDownloadOptions): Promise<string> {
    this.isProcessingSubject.next(true)
    this.downloadProgressSubject.next({
      phase: 'downloading',
      percent: 0,
      message: 'Starting download...',
      chartId: options.chartId,
    })

    try {
      return await window.electron.invoke.artDownloadImage(options)
    } catch (err) {
      this.downloadProgressSubject.next({
        phase: 'error',
        percent: 0,
        message: `Error: ${err}`,
        chartId: options.chartId,
      })
      throw err
    } finally {
      this.isProcessingSubject.next(false)
    }
  }

  async generateBackground(options: BackgroundGenerateOptions): Promise<string> {
    this.isProcessingSubject.next(true)
    this.downloadProgressSubject.next({
      phase: 'processing',
      percent: 0,
      message: 'Generating background...',
      chartId: options.chartId,
    })

    try {
      return await window.electron.invoke.artGenerateBackground(options)
    } catch (err) {
      this.downloadProgressSubject.next({
        phase: 'error',
        percent: 0,
        message: `Error: ${err}`,
        chartId: options.chartId,
      })
      throw err
    } finally {
      this.isProcessingSubject.next(false)
    }
  }

  async getChartsMissingAlbumArt(limit: number = 10000): Promise<ChartArtMatch[]> {
    try {
      return await window.electron.invoke.artGetChartsMissingAlbumArt(limit)
    } catch (err) {
      console.error('Failed to get charts missing album art:', err)
      return []
    }
  }

  async getChartsMissingBackground(limit: number = 10000): Promise<ChartArtMatch[]> {
    try {
      return await window.electron.invoke.artGetChartsMissingBackground(limit)
    } catch (err) {
      console.error('Failed to get charts missing background:', err)
      return []
    }
  }

  async checkChartAssets(chartId: number): Promise<{ hasAlbumArt: boolean; hasBackground: boolean; albumArtPath?: string; backgroundPath?: string }> {
    try {
      return await window.electron.invoke.artCheckChartAssets(chartId)
    } catch (err) {
      console.error('Failed to check chart assets:', err)
      return { hasAlbumArt: false, hasBackground: false }
    }
  }

  async batchFetchAlbumArt(chartIds: number[]): Promise<{ success: number; failed: number; skipped: number }> {
    this.isProcessingSubject.next(true)
    try {
      return await window.electron.invoke.artBatchFetchAlbumArt(chartIds)
    } finally {
      this.isProcessingSubject.next(false)
    }
  }

  async batchGenerateBackgrounds(chartIds: number[]): Promise<{ success: number; failed: number; skipped: number }> {
    this.isProcessingSubject.next(true)
    try {
      return await window.electron.invoke.artBatchGenerateBackgrounds(chartIds)
    } finally {
      this.isProcessingSubject.next(false)
    }
  }

  get isProcessing(): boolean {
    return this.isProcessingSubject.value
  }

  get downloadProgress(): ArtDownloadProgress | null {
    return this.downloadProgressSubject.value
  }
}
