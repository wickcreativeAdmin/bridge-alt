import { IpcInvokeHandlers, IpcToMainEmitHandlers } from '../src-shared/interfaces/ipc.interface.js'
import { catalogGetCharts, catalogGetChart, catalogGetDistinct, catalogGetLibraryPaths, catalogAddLibraryPath, catalogRemoveLibraryPath, catalogGetStats, catalogOpenFolder, catalogScan, catalogUpdateChart, catalogGetRemovalFolder, catalogSetRemovalFolder, catalogClearRemovalFolder, catalogRemoveChart, catalogRemoveCharts } from './ipc/catalog/CatalogHandler.ipc.js'
import { videoSearchYouTube, videoSearch, videoGetInfo, videoDownload, videoDownloadFromUrl, videoSelectLocalFile, videoImportLocal, videoCancelDownload, videoCheckTools, videoGetChartsMissingVideo, videoBuildSearchQuery, videoBatchDownload, videoDeleteFromChart } from './ipc/video-sync/VideoSyncHandler.ipc.js'
import { artSearchAlbumArt, artDownloadImage, artGenerateBackground, artGetChartsMissingAlbumArt, artGetChartsMissingBackground, artCheckChartAssets, artBatchFetchAlbumArt, artBatchGenerateBackgrounds, artDeleteBackground, artDeleteAlbumArt, artBatchDeleteBackgrounds, artBatchRegenerateBackgrounds } from './ipc/art-studio/ArtStudioHandler.ipc.js'
import { lyricsSearch, lyricsGet, lyricsGetById, lyricsDownload, lyricsGetChartsMissing, lyricsBatchDownload, lyricsCheckChart, lyricsDelete, lyricsGetAudioPath } from './ipc/lyrics/LyricsHandler.ipc.js'
import { download } from './ipc/DownloadHandler.ipc.js'
import { scanIssues } from './ipc/issue-scan/IssueScanHandler.ipc.js'
import { getSettings, setSettings } from './ipc/SettingsHandler.ipc.js'
import { downloadUpdate, getCurrentVersion, getUpdateAvailable, quitAndInstall, retryUpdate } from './ipc/UpdateHandler.ipc.js'
import { getPlatform, getThemeColors, isMaximized, maximize, minimize, openUrl, quit, restore, showFile, showFolder, showOpenDialog, toggleDevTools } from './ipc/UtilHandlers.ipc.js'

export function getIpcInvokeHandlers(): IpcInvokeHandlers {
	return {
		getSettings,
		getCurrentVersion,
		getPlatform,
		getUpdateAvailable,
		isMaximized,
		showOpenDialog,
		getThemeColors,
		// Catalog Manager
		catalogGetLibraryPaths,
		catalogAddLibraryPath,
		catalogRemoveLibraryPath,
		catalogScan,
		catalogGetCharts,
		catalogGetChart,
		catalogGetStats,
		catalogUpdateChart,
		catalogGetDistinct,
		catalogGetRemovalFolder,
		catalogSetRemovalFolder,
		catalogClearRemovalFolder,
		catalogRemoveChart,
		catalogRemoveCharts,
		// Video Sync
		videoSearchYouTube,
		videoSearch,
		videoGetInfo,
		videoDownload,
		videoDownloadFromUrl,
		videoSelectLocalFile,
		videoImportLocal,
		videoCancelDownload,
		videoCheckTools,
		videoGetChartsMissingVideo,
		videoBuildSearchQuery,
		// Art Studio
		artSearchAlbumArt,
		artDownloadImage,
		artGenerateBackground,
		artGetChartsMissingAlbumArt,
		artGetChartsMissingBackground,
		artCheckChartAssets,
		artBatchFetchAlbumArt,
		artBatchGenerateBackgrounds,
		artDeleteBackground,
		artDeleteAlbumArt,
		artBatchDeleteBackgrounds,
		artBatchRegenerateBackgrounds,
		// Video batch and delete
		videoBatchDownload,
		videoDeleteFromChart,
		// Lyrics
		lyricsSearch,
		lyricsGet,
		lyricsGetById,
		lyricsDownload,
		lyricsGetChartsMissing,
		lyricsBatchDownload,
		lyricsCheckChart,
		lyricsDelete,
		lyricsGetAudioPath,
	}
}

export function getIpcToMainEmitHandlers(): IpcToMainEmitHandlers {
	return {
		download,
		setSettings,
		downloadUpdate,
		retryUpdate,
		quitAndInstall,
		openUrl,
		toggleDevTools,
		maximize,
		minimize,
		restore,
		quit,
		showFile,
		showFolder,
		scanIssues,
		// Catalog Manager
		catalogOpenFolder,
	}
}
